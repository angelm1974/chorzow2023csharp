﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MojeFormy
{
    public class Samochod
    {
        public String ?Marka { get; set; }
        public String ?Model { get; set; }
        public String ?Kolor { get; set; }
        public  Decimal Rocznik { get; set; }
    }
}
